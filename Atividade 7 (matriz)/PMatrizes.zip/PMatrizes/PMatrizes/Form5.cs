﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] aluno = new string[8, 10];
            string[] gabarito = new string [10]{"a","b", "c", "d","e", "a", "b", "c", "d", "e" };
            string auxiliar;
            


            for (int c = 0; c < 8; c++) {
                for (int l = 0; l < 10; l++) {
                    auxiliar = Interaction.InputBox($"Digite o aluno {c + 1}° do questão {l + 1}°", "Entrada de Dados");
                    auxiliar = auxiliar.ToLower();
                    if (auxiliar == "a"|| auxiliar == "b" || auxiliar == "c" || auxiliar == "d" ||auxiliar == "e") {
                        aluno [c,l] = auxiliar;
                        if ((String.Compare(aluno[c, l], gabarito[l], true) == 0))
                        {
                            listBoxGabarito.Items.Add($"Aluno {c + 1}, Questão {l + 1}: ACERTOU! (Resposta: {gabarito[l]})");

                        }
                        else
                        {
                            listBoxGabarito.Items.Add($"Aluno {c + 1}, Questão {l + 1}: ERROU! (Respondeu: {aluno[c, l]}, Correta: {gabarito[l]})");
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Resposta inválida! Digite apenas A, B, C, D ou E para o aluno {c + 1}, questão {l + 1}.", "Erro");
                        l--;
                    }


            
                }
            }
        }
    }
}
