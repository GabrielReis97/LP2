﻿namespace Pmatrizes
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNomes = new System.Windows.Forms.Button();
            this.listBoxComprimento = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnNomes
            // 
            this.btnNomes.BackColor = System.Drawing.Color.White;
            this.btnNomes.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNomes.Location = new System.Drawing.Point(295, 12);
            this.btnNomes.Name = "btnNomes";
            this.btnNomes.Size = new System.Drawing.Size(173, 100);
            this.btnNomes.TabIndex = 4;
            this.btnNomes.Text = " Carregar os Nomes";
            this.btnNomes.UseVisualStyleBackColor = false;
            this.btnNomes.Click += new System.EventHandler(this.btnNomes_Click);
            // 
            // listBoxComprimento
            // 
            this.listBoxComprimento.Font = new System.Drawing.Font("Modern No. 20", 14.25F);
            this.listBoxComprimento.FormattingEnabled = true;
            this.listBoxComprimento.ItemHeight = 21;
            this.listBoxComprimento.Location = new System.Drawing.Point(255, 130);
            this.listBoxComprimento.Name = "listBoxComprimento";
            this.listBoxComprimento.Size = new System.Drawing.Size(246, 298);
            this.listBoxComprimento.TabIndex = 5;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SeaGreen;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxComprimento);
            this.Controls.Add(this.btnNomes);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNomes;
        private System.Windows.Forms.ListBox listBoxComprimento;
    }
}