﻿namespace PMatrizes
{
    partial class Exercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEX5 = new System.Windows.Forms.Button();
            this.listboxgabarito = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEX5
            // 
            this.btnEX5.Location = new System.Drawing.Point(56, 169);
            this.btnEX5.Name = "btnEX5";
            this.btnEX5.Size = new System.Drawing.Size(270, 71);
            this.btnEX5.TabIndex = 0;
            this.btnEX5.Text = "Exercicio 5";
            this.btnEX5.UseVisualStyleBackColor = true;
            this.btnEX5.Click += new System.EventHandler(this.btnEX5_Click);
            // 
            // listboxgabarito
            // 
            this.listboxgabarito.FormattingEnabled = true;
            this.listboxgabarito.ItemHeight = 16;
            this.listboxgabarito.Location = new System.Drawing.Point(370, 29);
            this.listboxgabarito.Name = "listboxgabarito";
            this.listboxgabarito.Size = new System.Drawing.Size(327, 356);
            this.listboxgabarito.TabIndex = 1;
            // 
            // Exercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listboxgabarito);
            this.Controls.Add(this.btnEX5);
            this.Name = "Exercicio5";
            this.Text = "Exercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEX5;
        private System.Windows.Forms.ListBox listboxgabarito;
    }
}