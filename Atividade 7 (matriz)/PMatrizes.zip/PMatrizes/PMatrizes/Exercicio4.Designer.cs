﻿namespace PMatrizes
{
    partial class Exercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEX4 = new System.Windows.Forms.Button();
            this.listboxcomprimentos = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEX4
            // 
            this.btnEX4.Location = new System.Drawing.Point(63, 142);
            this.btnEX4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEX4.Name = "btnEX4";
            this.btnEX4.Size = new System.Drawing.Size(189, 90);
            this.btnEX4.TabIndex = 0;
            this.btnEX4.Text = "Exercicio 4 dnv";
            this.btnEX4.UseVisualStyleBackColor = true;
            this.btnEX4.Click += new System.EventHandler(this.btnEX4_Click);
            // 
            // listboxcomprimentos
            // 
            this.listboxcomprimentos.FormattingEnabled = true;
            this.listboxcomprimentos.ItemHeight = 16;
            this.listboxcomprimentos.Location = new System.Drawing.Point(385, 43);
            this.listboxcomprimentos.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.listboxcomprimentos.Name = "listboxcomprimentos";
            this.listboxcomprimentos.Size = new System.Drawing.Size(337, 324);
            this.listboxcomprimentos.TabIndex = 1;
            // 
            // Exercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(761, 412);
            this.Controls.Add(this.listboxcomprimentos);
            this.Controls.Add(this.btnEX4);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Exercicio4";
            this.Text = "Form2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEX4;
        private System.Windows.Forms.ListBox listboxcomprimentos;
    }
}