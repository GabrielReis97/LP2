﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class btnsair : Form
    {
        double numero1, numero2, resultado;

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnumero2.Text, out numero2))
            {
                MessageBox.Show("Numero 2 invalido!");
                txtnumero2.Focus();
            }
        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if(numero2==0)
            {
                MessageBox.Show("Nao existe divisão por 0!");
            }
            else
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString("N2");
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Clear();
            txtnumero2.Clear();
            txtresultado.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnumero1.Text, out numero1))
            {
                MessageBox.Show("Numero 1 invalido!");
                txtnumero1.Focus();
            }
        }

        public btnsair()
        {
            InitializeComponent();
        }
    }
}
