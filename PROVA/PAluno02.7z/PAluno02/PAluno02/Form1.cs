﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnexecutar_Click(object sender, EventArgs e)
        {

            string auxiliar;
            float nota1, nota2, nota3, media, mediageral;
            int aluno = 1, professor = 1;
            nota1 = 0;
            nota2 = 0;
            nota3 = 0;
            media = 0;
            mediageral = 0;
            while(aluno < 3)
            {
                if(professor < 4)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno}° com o professor {professor}°", "Nota");
                    if(auxiliar == "0")
                    {
                        nota1 = 0;
                    }
                    if (auxiliar == "1")
                    {
                        nota1 = 1;
                    }
                    if (auxiliar == "2")
                    {
                        nota1 = 2;
                    }
                    if (auxiliar == "3")
                    {
                        nota1 = 3;
                    }
                    if (auxiliar == "4")
                    {
                        nota1 = 4;
                    }
                    if (auxiliar == "5")
                    {
                        nota1 = 5;
                    }
                    if (auxiliar == "6")
                    {
                        nota1 = 6;
                    }
                    if (auxiliar == "7")
                    {
                        nota1 = 7;
                    }
                    if (auxiliar == "8")
                    {
                        nota1 = 8;
                    }
                    if (auxiliar == "9")
                    {
                        nota1 = 9;
                    }
                    if (auxiliar == "10")
                    {
                        nota1 = 10;
                    }
                }
                professor = professor + 1;
                if (professor < 3)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno}° com o professor {professor}°", "Nota");
                    if (auxiliar == "0")
                    {
                        nota2 = 0;
                    }
                    if (auxiliar == "1")
                    {
                        nota1 = 1;
                    }
                    if (auxiliar == "2")
                    {
                        nota1 = 2;
                    }
                    if (auxiliar == "3")
                    {
                        nota2 = 3;
                    }
                    if (auxiliar == "4")
                    {
                        nota2 = 4;
                    }
                    if (auxiliar == "5")
                    {
                        nota2 = 5;
                    }
                    if (auxiliar == "6")
                    {
                        nota2 = 6;
                    }
                    if (auxiliar == "7")
                    {
                        nota2 = 7;
                    }
                    if (auxiliar == "8")
                    {
                        nota2 = 8;
                    }
                    if (auxiliar == "9")
                    {
                        nota2 = 9;
                    }
                    if (auxiliar == "10")
                    {
                        nota2 = 10;
                    }
                }
                professor = professor + 1;
                if (professor < 3)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do aluno {aluno}° com o professor {professor}°", "Nota");
                    if (auxiliar == "0")
                    {
                        nota3 = 0;
                    }
                    if (auxiliar == "1")
                    {
                        nota3 = 1;
                    }
                    if (auxiliar == "2")
                    {
                        nota3 = 2;
                    }
                    if (auxiliar == "3")
                    {
                        nota3 = 3;
                    }
                    if (auxiliar == "4")
                    {
                        nota3 = 4;
                    }
                    if (auxiliar == "5")
                    {
                        nota3 = 5;
                    }
                    if (auxiliar == "6")
                    {
                        nota3 = 6;
                    }
                    if (auxiliar == "7")
                    {
                        nota3 = 7;
                    }
                    if (auxiliar == "8")
                    {
                        nota3 = 8;
                    }
                    if (auxiliar == "9")
                    {
                        nota3 = 9;
                    }
                    if (auxiliar == "10")
                    {
                        nota3 = 10;
                    }
                }
                media = (nota1 + nota2 + nota3) / 3;
                professor = professor - 2;               
                mediageral = mediageral + media;

                listBoxnota.Items.Add($"Aluno 0{aluno}NotaProfessor {professor}: {nota1}   NotaProfessor{professor + 1}: {nota2} NotaProfessor {professor + 2}: {nota3} Media {media}");

                aluno = aluno + 1;

            }
            listBoxnota.Items.Add($"-----------------------------");
            listBoxnota.Items.Add($"Media Geral Alunos{mediageral}");
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            listBoxnota.ClearSelected();
        }
    }
}
