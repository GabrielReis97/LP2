﻿namespace PAluno02
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnexecutar = new System.Windows.Forms.Button();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.listBoxnota = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnexecutar
            // 
            this.btnexecutar.Location = new System.Drawing.Point(101, 99);
            this.btnexecutar.Name = "btnexecutar";
            this.btnexecutar.Size = new System.Drawing.Size(151, 91);
            this.btnexecutar.TabIndex = 0;
            this.btnexecutar.Text = "EXECUTAR";
            this.btnexecutar.UseVisualStyleBackColor = true;
            this.btnexecutar.Click += new System.EventHandler(this.btnexecutar_Click);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(101, 254);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(151, 96);
            this.btnlimpar.TabIndex = 1;
            this.btnlimpar.Text = "LIMPAR";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // listBoxnota
            // 
            this.listBoxnota.FormattingEnabled = true;
            this.listBoxnota.Location = new System.Drawing.Point(381, 63);
            this.listBoxnota.Name = "listBoxnota";
            this.listBoxnota.Size = new System.Drawing.Size(370, 342);
            this.listBoxnota.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBoxnota);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.btnexecutar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnexecutar;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.ListBox listBoxnota;
    }
}

