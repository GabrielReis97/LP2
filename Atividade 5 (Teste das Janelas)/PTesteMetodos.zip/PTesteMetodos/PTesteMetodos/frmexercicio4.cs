﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class forms4 : Form
    {
        public forms4()
        {
            InitializeComponent();
        }

        private void btnnumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnumero = 0;
            while (contador < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[contador]))
                {
                    contnumero ++;
                }
                contador++;
            }
            MessageBox.Show($"tem {contnumero} numeros");
        }

        private void btnletra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtfrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letra(s)");
        }

        private void btnbranco_Click(object sender, EventArgs e)
        {
            string frase = rchtxtfrase.Text;
            int naoTem = 0;

            for (int localizador = 0; localizador < rchtxtfrase.Text.Length; localizador++)
            {
                if (Char.IsWhiteSpace(frase, localizador))
                {

                    MessageBox.Show($"O primeiro espaço em branco está na posição {localizador + 1}.");
                    naoTem++;
                    break;

                }

            }
            if (naoTem == 0)
            {
                MessageBox.Show("Não há espaços em branco no texto.");
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
