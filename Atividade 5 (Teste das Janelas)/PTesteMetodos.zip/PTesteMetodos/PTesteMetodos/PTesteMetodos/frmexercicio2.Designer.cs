﻿namespace PTesteMetodos
{
    partial class forms2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.btncompara = new System.Windows.Forms.Button();
            this.btninserir = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(275, 110);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Palavra 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(275, 215);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Palavra 2";
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(655, 110);
            this.txtpalavra1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(132, 22);
            this.txtpalavra1.TabIndex = 2;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(655, 215);
            this.txtpalavra2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(132, 22);
            this.txtpalavra2.TabIndex = 3;
            // 
            // btncompara
            // 
            this.btncompara.Location = new System.Drawing.Point(460, 345);
            this.btncompara.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btncompara.Name = "btncompara";
            this.btncompara.Size = new System.Drawing.Size(140, 80);
            this.btncompara.TabIndex = 4;
            this.btncompara.Text = "Comparar";
            this.btncompara.UseVisualStyleBackColor = true;
            this.btncompara.Click += new System.EventHandler(this.btncompara_Click);
            // 
            // btninserir
            // 
            this.btninserir.Location = new System.Drawing.Point(241, 345);
            this.btninserir.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btninserir.Name = "btninserir";
            this.btninserir.Size = new System.Drawing.Size(127, 80);
            this.btninserir.TabIndex = 5;
            this.btninserir.Text = "inserir 1 no meio do 2";
            this.btninserir.UseVisualStyleBackColor = true;
            this.btninserir.Click += new System.EventHandler(this.btninserir_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(676, 345);
            this.btninserir2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(144, 80);
            this.btninserir2.TabIndex = 6;
            this.btninserir2.Text = "inserir 2 * no meio do 1";
            this.btninserir2.UseVisualStyleBackColor = true;
            this.btninserir2.Click += new System.EventHandler(this.btninserir2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(38, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(140, 79);
            this.button1.TabIndex = 7;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // forms2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir);
            this.Controls.Add(this.btncompara);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "forms2";
            this.Text = "frmexercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Button btncompara;
        private System.Windows.Forms.Button btninserir;
        private System.Windows.Forms.Button btninserir2;
        private System.Windows.Forms.Button button1;
    }
}