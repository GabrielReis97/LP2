﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class forms4 : Form
    {
        public forms4()
        {
            InitializeComponent();
        }

        private void btnnumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnumero = 0;
            while (contador < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[contador]))
                {
                    contnumero ++;
                }
                contador++;
            }
            MessageBox.Show($"tem {contnumero} numeros");
        }

        private void btnletra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtfrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show($"O texto tem {contaLetra} letra(s)");
        }

        private void btnbranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rchtxtfrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtfrase.Text[i]))
                {
                    posicao++;
                    break;
                }
            }
            MessageBox.Show($"A posição do primeiro caracter em branco é : {posicao}.");
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
