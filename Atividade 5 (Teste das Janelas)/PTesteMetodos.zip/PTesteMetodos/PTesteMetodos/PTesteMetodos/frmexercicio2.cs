﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class forms2 : Form
    {
        public forms2()
        {
            InitializeComponent();
        }

        private void btninserir_Click(object sender, EventArgs e)
        {
            int Metade = txtpalavra2.Text.Length / 2;
            txtpalavra2.Text = txtpalavra2.Text.Substring(0, Metade) + txtpalavra1.Text +
            txtpalavra2.Text.Substring(Metade, txtpalavra2.Text.Length - Metade);
        }

        private void btncompara_Click(object sender, EventArgs e)
        {
            if (string.Compare(txtpalavra1.Text, txtpalavra2.Text, true) == 0)
                MessageBox.Show("São Iguais");
            else
                MessageBox.Show("São Diferentes");
        }

        private void btninserir2_Click(object sender, EventArgs e)
        {
            int Metade = txtpalavra1.Text.Length / 2;
            txtpalavra2.Text = txtpalavra1.Text.Insert(Metade, "* *");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
