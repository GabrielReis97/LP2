﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Executar Copiar");
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Executar Colar");
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void fORMS2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<forms2>().Count() > 0 )
            {
                MessageBox.Show("forms ja existe");
                Application.OpenForms["forms2"].BringToFront();
            }
            else
            {
                forms2 obj2 = new forms2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Maximized;
                obj2.Show();
            }
        }

        private void exercicios3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<forms3>().Count() > 0)
            {
                MessageBox.Show("forms ja existe");
                Application.OpenForms["forms3"].BringToFront();
            }
            else
            {
                forms3 obj3 = new forms3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Maximized;
                obj3.Show();
            }
        }

        private void exercicio4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<forms4>().Count() > 0)
            {
                MessageBox.Show("forms ja existe");
                Application.OpenForms["forms4"].BringToFront();
            }
            else
            {
                forms4 obj4 = new forms4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Maximized;
                obj4.Show();
            }
        }

        private void exercicio5ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<forms5>().Count() > 0)
            {
                MessageBox.Show("forms ja existe");
                Application.OpenForms["forms5"].BringToFront();
            }
            else
            {
                forms5 obj5 = new forms5();
                obj5.MdiParent = this;
                obj5.WindowState = FormWindowState.Maximized;
                obj5.Show();
            }

        }
    }
}
