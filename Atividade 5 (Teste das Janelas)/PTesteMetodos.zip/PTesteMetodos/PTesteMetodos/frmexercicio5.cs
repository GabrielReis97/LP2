﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class forms5 : Form
    {
        double Num1;
        double Num2;
        public forms5()
        {
            InitializeComponent();
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnsortear_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out Num1) || (!double.TryParse(txtnum2.Text, out Num2)) || (Num2 <= Num1))
            {
                MessageBox.Show("Numero Invalido");
                txtnum1.Focus();
            }
            else
            {
                Random obj5 = new Random();
                int x = obj5.Next((int)Num1, (int)Num2);
                MessageBox.Show("numero sorteado" + x);
            }
        }
    }
}
