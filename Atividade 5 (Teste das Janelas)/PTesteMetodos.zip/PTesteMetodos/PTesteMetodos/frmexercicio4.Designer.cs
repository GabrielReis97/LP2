﻿namespace PTesteMetodos
{
    partial class forms4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnnumero = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btnletra = new System.Windows.Forms.Button();
            this.Btnsair = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(183, 47);
            this.rchtxtfrase.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(605, 154);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btnnumero
            // 
            this.btnnumero.Location = new System.Drawing.Point(183, 321);
            this.btnnumero.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnnumero.Name = "btnnumero";
            this.btnnumero.Size = new System.Drawing.Size(165, 130);
            this.btnnumero.TabIndex = 1;
            this.btnnumero.Text = "conta os numeros numeros";
            this.btnnumero.UseVisualStyleBackColor = true;
            this.btnnumero.Click += new System.EventHandler(this.btnnumero_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(408, 321);
            this.btnbranco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(165, 130);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "posição do primeiro caracter branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            this.btnbranco.Click += new System.EventHandler(this.btnbranco_Click);
            // 
            // btnletra
            // 
            this.btnletra.Location = new System.Drawing.Point(631, 321);
            this.btnletra.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnletra.Name = "btnletra";
            this.btnletra.Size = new System.Drawing.Size(159, 130);
            this.btnletra.TabIndex = 3;
            this.btnletra.Text = "conta os caracters de letras";
            this.btnletra.UseVisualStyleBackColor = true;
            this.btnletra.Click += new System.EventHandler(this.btnletra_Click);
            // 
            // Btnsair
            // 
            this.Btnsair.Location = new System.Drawing.Point(36, 47);
            this.Btnsair.Name = "Btnsair";
            this.Btnsair.Size = new System.Drawing.Size(83, 45);
            this.Btnsair.TabIndex = 4;
            this.Btnsair.Text = "Sair";
            this.Btnsair.UseVisualStyleBackColor = true;
            this.Btnsair.Click += new System.EventHandler(this.Btnsair_Click);
            // 
            // forms4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(935, 543);
            this.Controls.Add(this.Btnsair);
            this.Controls.Add(this.btnletra);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnnumero);
            this.Controls.Add(this.rchtxtfrase);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "forms4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btnnumero;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btnletra;
        private System.Windows.Forms.Button Btnsair;
    }
}