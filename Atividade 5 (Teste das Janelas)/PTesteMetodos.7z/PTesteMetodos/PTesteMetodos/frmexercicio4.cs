﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class forms4 : Form
    {
        public forms4()
        {
            InitializeComponent();
        }

        private void btnnumero_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contnumero = 0;
            while (contador < rchtxtfrase.Text.Length)
            {
                if (char.IsNumber(rchtxtfrase.Text[contador]))
                {
                    contnumero ++;
                }
                contador++;
            }
            MessageBox.Show($"tem {contnumero} numeros");
        }

        private void btnletra_Click(object sender, EventArgs e)
        {
            foreach(char c in )
        }
    }
}
