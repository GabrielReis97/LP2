﻿namespace PTesteMetodos
{
    partial class forms3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninverte = new System.Windows.Forms.Button();
            this.btnremove = new System.Windows.Forms.Button();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btninverte
            // 
            this.btninverte.Location = new System.Drawing.Point(498, 269);
            this.btninverte.Name = "btninverte";
            this.btninverte.Size = new System.Drawing.Size(95, 65);
            this.btninverte.TabIndex = 12;
            this.btninverte.Text = "inverte 1&°";
            this.btninverte.UseVisualStyleBackColor = true;
            this.btninverte.Click += new System.EventHandler(this.btninverte_Click);
            // 
            // btnremove
            // 
            this.btnremove.Location = new System.Drawing.Point(211, 269);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(105, 65);
            this.btnremove.TabIndex = 11;
            this.btnremove.Text = "Remove o primeiro do segundo";
            this.btnremove.UseVisualStyleBackColor = true;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(493, 183);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra2.TabIndex = 10;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(493, 97);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(100, 20);
            this.txtpalavra1.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(208, 183);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 8;
            this.label2.Text = "Palavra 2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(208, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Palavra 1";
            // 
            // forms3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninverte);
            this.Controls.Add(this.btnremove);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "forms3";
            this.Text = "frmexercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btninverte;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}