﻿namespace PTesteMetodos
{
    partial class forms4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtfrase = new System.Windows.Forms.RichTextBox();
            this.btnnumero = new System.Windows.Forms.Button();
            this.btnbranco = new System.Windows.Forms.Button();
            this.btnletra = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtfrase
            // 
            this.rchtxtfrase.Location = new System.Drawing.Point(137, 38);
            this.rchtxtfrase.Name = "rchtxtfrase";
            this.rchtxtfrase.Size = new System.Drawing.Size(455, 126);
            this.rchtxtfrase.TabIndex = 0;
            this.rchtxtfrase.Text = "";
            // 
            // btnnumero
            // 
            this.btnnumero.Location = new System.Drawing.Point(137, 261);
            this.btnnumero.Name = "btnnumero";
            this.btnnumero.Size = new System.Drawing.Size(124, 106);
            this.btnnumero.TabIndex = 1;
            this.btnnumero.Text = "conta os numeros numeros";
            this.btnnumero.UseVisualStyleBackColor = true;
            this.btnnumero.Click += new System.EventHandler(this.btnnumero_Click);
            // 
            // btnbranco
            // 
            this.btnbranco.Location = new System.Drawing.Point(306, 261);
            this.btnbranco.Name = "btnbranco";
            this.btnbranco.Size = new System.Drawing.Size(124, 106);
            this.btnbranco.TabIndex = 2;
            this.btnbranco.Text = "posição do primeiro caracter branco";
            this.btnbranco.UseVisualStyleBackColor = true;
            // 
            // btnletra
            // 
            this.btnletra.Location = new System.Drawing.Point(473, 261);
            this.btnletra.Name = "btnletra";
            this.btnletra.Size = new System.Drawing.Size(119, 106);
            this.btnletra.TabIndex = 3;
            this.btnletra.Text = "conta os caracters de letras";
            this.btnletra.UseVisualStyleBackColor = true;
            this.btnletra.Click += new System.EventHandler(this.btnletra_Click);
            // 
            // forms4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 441);
            this.Controls.Add(this.btnletra);
            this.Controls.Add(this.btnbranco);
            this.Controls.Add(this.btnnumero);
            this.Controls.Add(this.rchtxtfrase);
            this.Name = "forms4";
            this.Text = "frmexercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtfrase;
        private System.Windows.Forms.Button btnnumero;
        private System.Windows.Forms.Button btnbranco;
        private System.Windows.Forms.Button btnletra;
    }
}