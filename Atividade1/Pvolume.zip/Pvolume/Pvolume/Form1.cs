﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; /* Globais */

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura) || 
                (altura <=0))
            {
                MessageBox.Show("altura invalida");
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura) ||
              (altura <= 0))
            {
                MessageBox.Show("altura invalida");
                txtAltura.Focus();
            }
            else 
            if (!double.TryParse(txtRaio.Text, out raio) ||
             (raio <= 0))
            {
                MessageBox.Show("raio invalido!");
                txtRaio.Focus();
            }
            else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text= volume.ToString("N2");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtRaio.Text = "";
            txtAltura.Text= string.Empty;
            txtVolume.Clear();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtRaio.Text, out raio) ||
                (raio<= 0))
            {
                MessageBox.Show("raio invalido!");
            }
        }
    }
}
