﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Exercicio4 : Form
    {
        public Exercicio4()
        {
            InitializeComponent();
        }

        private void btnEX4_Click(object sender, EventArgs e)
        {
            string auxiliar; 
            string[] vetor =  new string[10];

            for (int qtdnomes = 0; qtdnomes < 2; qtdnomes++)
            {
                auxiliar = Interaction.InputBox($"digite o {qtdnomes + 1} nome", "quais os nomes ?");
            }
        }
    }
}
