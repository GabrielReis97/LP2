﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for(int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i + 1} numero", "Entrada de dados");
                if (auxiliar == "")
                    break;
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero Invalido");
                    i--;
                }
            }
            Array.Reverse(vetor);

            auxiliar = "";
            foreach (int j in vetor)
                auxiliar += j + "\n";
            MessageBox.Show(auxiliar);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList();
            lista.Add("Ana");
            lista.Add("Andre");
            lista.Add("Beatriz");
            lista.Add("Camila João");
            lista.Add("Joana");
            lista.Add("Octavio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            lista.Remove("Octavio");

            string auxiliar = "" ;
            foreach(string i in lista)
            auxiliar += i + ";";
            
            MessageBox.Show(auxiliar);
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            double[] media = new double[20];
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            string saida = "";

            for (int aluno = 0; aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3; nota++)
                {
                    auxiliar = Interaction.InputBox($"Digite o {nota + 1} nota", "Entrada de dados");
                    if (auxiliar == "")
                        break;
                    if (!double.TryParse(auxiliar, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Numero Invalido");
                        nota--;
                    }
                    media[aluno] += notas[aluno, nota];
                }
                media[aluno] = media[aluno] / 3;
                saida += "Aluno" + (aluno + 1) + ":" + "media" + media[aluno].ToString("n2") + "\n";
            }
            MessageBox.Show(saida);
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            Exercicio4 objexercicio4 = new Exercicio4();
            objexercicio4.Show();
        }
    }
}
