﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double ladoa, ladob, ladoc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txta.Clear();
            txtb.Clear();
            txtc.Clear();
        }
        private void btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtc_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtc.Text, out ladoc) || (txtc.Text == "0") || (txtc.Text == "")))
            {
                MessageBox.Show("Lado c inválido!");
                txtc.Focus();
            }
        }

        private void txta_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txta.Text, out ladoa) || (txta.Text == "0") || (txta.Text == ""))
            {
                MessageBox.Show("Lado a inválido!");
                txta.Focus();

            }

        }

        private void txtb_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtb.Text, out ladob) || (txtb.Text == "0") || (txtb.Text == ""))
            {
                MessageBox.Show("Lado b inválido!");
                txtb.Focus();
            }
        }
    
        private void btnanalise_Click(object sender, EventArgs e)
        {
            if ((Math.Abs(ladob - ladoc) < ladoa) & (ladoa < ladob + ladoc))
            {
                if ((Math.Abs(ladoa - ladoc) < ladob) & (ladob < ladoa + ladoc))
                {
                    if ((Math.Abs(ladoa - ladob) < ladoc) & (ladoc < ladoa + ladob))
                    {
                        if ((ladoa == ladoc) && (ladob == ladoc))
                            MessageBox.Show("Seu triangulo é um triângulo equilatero!");
                        else
                            if ((ladoa == ladob) | (ladoa == ladoc) | (ladob == ladoc))
                            MessageBox.Show("Seu triangulo é um triangulo Isosceles!");
                        else
                            MessageBox.Show("Seu triangulo é um triangulo Escaleno!");
                    }
                    else
                        MessageBox.Show("Lado c invalido!");
                }
                else
                    MessageBox.Show("Lado b invalido!");
            }
            else
                MessageBox.Show("Lado a invalido!");
        }
    }

}
