﻿namespace Ptriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txta = new System.Windows.Forms.TextBox();
            this.txtb = new System.Windows.Forms.TextBox();
            this.txtc = new System.Windows.Forms.TextBox();
            this.btnlimpar = new System.Windows.Forms.Button();
            this.btnanalise = new System.Windows.Forms.Button();
            this.btnfechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(203, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "LADO A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 136);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "LADO B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(203, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "LADO C";
            // 
            // txta
            // 
            this.txta.Location = new System.Drawing.Point(416, 62);
            this.txta.Name = "txta";
            this.txta.Size = new System.Drawing.Size(151, 22);
            this.txta.TabIndex = 3;
            this.txta.Validated += new System.EventHandler(this.txta_Validated);
            // 
            // txtb
            // 
            this.txtb.Location = new System.Drawing.Point(416, 136);
            this.txtb.Name = "txtb";
            this.txtb.Size = new System.Drawing.Size(151, 22);
            this.txtb.TabIndex = 4;
            this.txtb.Validated += new System.EventHandler(this.txtb_Validated);
            // 
            // txtc
            // 
            this.txtc.Location = new System.Drawing.Point(416, 203);
            this.txtc.Name = "txtc";
            this.txtc.Size = new System.Drawing.Size(151, 22);
            this.txtc.TabIndex = 5;
            this.txtc.Validated += new System.EventHandler(this.txtc_Validated);
            // 
            // btnlimpar
            // 
            this.btnlimpar.Location = new System.Drawing.Point(206, 369);
            this.btnlimpar.Name = "btnlimpar";
            this.btnlimpar.Size = new System.Drawing.Size(168, 55);
            this.btnlimpar.TabIndex = 6;
            this.btnlimpar.Text = "Limpar";
            this.btnlimpar.UseVisualStyleBackColor = true;
            this.btnlimpar.Click += new System.EventHandler(this.btnlimpar_Click);
            // 
            // btnanalise
            // 
            this.btnanalise.Location = new System.Drawing.Point(206, 290);
            this.btnanalise.Name = "btnanalise";
            this.btnanalise.Size = new System.Drawing.Size(361, 57);
            this.btnanalise.TabIndex = 7;
            this.btnanalise.Text = "Analisar";
            this.btnanalise.UseVisualStyleBackColor = true;
            this.btnanalise.Click += new System.EventHandler(this.btnanalise_Click);
            // 
            // btnfechar
            // 
            this.btnfechar.Location = new System.Drawing.Point(416, 369);
            this.btnfechar.Name = "btnfechar";
            this.btnfechar.Size = new System.Drawing.Size(151, 55);
            this.btnfechar.TabIndex = 8;
            this.btnfechar.Text = "Fechar";
            this.btnfechar.UseVisualStyleBackColor = true;
            this.btnfechar.Click += new System.EventHandler(this.btnfechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 485);
            this.Controls.Add(this.btnfechar);
            this.Controls.Add(this.btnanalise);
            this.Controls.Add(this.btnlimpar);
            this.Controls.Add(this.txtc);
            this.Controls.Add(this.txtb);
            this.Controls.Add(this.txta);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txta;
        private System.Windows.Forms.TextBox txtb;
        private System.Windows.Forms.TextBox txtc;
        private System.Windows.Forms.Button btnlimpar;
        private System.Windows.Forms.Button btnanalise;
        private System.Windows.Forms.Button btnfechar;
    }
}

