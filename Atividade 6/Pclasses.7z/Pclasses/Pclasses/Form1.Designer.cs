﻿namespace Pclasses
{
    partial class btnHorista
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMensalista = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnteste = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMensalista
            // 
            this.btnMensalista.Location = new System.Drawing.Point(242, 185);
            this.btnMensalista.Name = "btnMensalista";
            this.btnMensalista.Size = new System.Drawing.Size(208, 114);
            this.btnMensalista.TabIndex = 0;
            this.btnMensalista.Text = "Mensalista";
            this.btnMensalista.UseVisualStyleBackColor = true;
            this.btnMensalista.Click += new System.EventHandler(this.btnMensalista_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(607, 185);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(208, 114);
            this.button2.TabIndex = 1;
            this.button2.Text = "Horista";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnteste
            // 
            this.btnteste.Location = new System.Drawing.Point(390, 392);
            this.btnteste.Name = "btnteste";
            this.btnteste.Size = new System.Drawing.Size(234, 75);
            this.btnteste.TabIndex = 2;
            this.btnteste.Text = "Teste Menssage Box";
            this.btnteste.UseVisualStyleBackColor = true;
            this.btnteste.Click += new System.EventHandler(this.btnteste_Click);
            // 
            // btnHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1083, 596);
            this.Controls.Add(this.btnteste);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnMensalista);
            this.Name = "btnHorista";
            this.Text = "form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMensalista;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnteste;
    }
}

