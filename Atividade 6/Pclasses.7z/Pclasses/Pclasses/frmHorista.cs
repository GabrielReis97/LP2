﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void btnhorista_Click(object sender, EventArgs e)
        {
            Horista objhorista = new Horista();

            objhorista.NomeEmpregado = txtNome.Text;
            objhorista.Matricula=Convert.ToInt32(txtMatricula.Text);
            objhorista.SalarioHora = Convert.ToDouble(txtSalario.Text);
            objhorista.NumeroHora= Convert.ToDouble(txthora.Text);
            objhorista.DataEntradaEmpresa=Convert.ToDateTime(txtdata.Text);
            objhorista.DiasFalta= Convert.ToInt32(txtfalta.Text);

            //mostrando valores
            MessageBox.Show("Nome;" + objhorista.NomeEmpregado + "\nmatricula:" +objhorista.Matricula+"\n Tempo Trabalho:"+objhorista.TempoTrabalho()+ "\n Salario:"+objhorista.SalarioBruto().ToString("N2"));



        }
    }
}
